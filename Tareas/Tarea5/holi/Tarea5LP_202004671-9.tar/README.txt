Sofía Parada
202004671-9

Para poder ejecutar esta tarea se necesitara la aplicación SWI-Prolog en el cual se abrira una consola
donde se tendra que llamar a las consultas realizadas en la tarea.
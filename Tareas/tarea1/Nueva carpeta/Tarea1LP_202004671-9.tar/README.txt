nombre: Sofía Parada
Rol: 202004671-9

Para usar el progama se debe usar python 3.10 y se ejecutara el codigo grafospp.py el cual lee un archivo de texto input.txt que contiene comandos
como prints que manipulan calles y camninos dependiendo de como lo pida la función el cual se vera reflejado en el output. Si los comandos calle
y camino tienen algun error en su estructura, el programa lo identificara mandandolo al archivo de texto errores.txt.
Sofía Parada
202004671-9

En esta Tarea se utlizó el lenguaje Java con su compilador javac versión 13.07 o mayor, y se ejecutara el codigo
Javation.java el cual inicializa la clase Jugador.java y las clases abtractas Persona.java y Edificio.java,
que son las clases padres de Granjero.java, Cientifico.java, Herrero.java y Granero.java, Laboratorio.java, 
Herrería.java, ZonaComun.java. También tenemos la interfaz Atraccion.java que esta implementada por las clases
Feria.java, Museo.java y Javapato.java.
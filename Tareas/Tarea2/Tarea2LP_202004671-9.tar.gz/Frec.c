#include <stdio.h>
#include <Frec.h>

Frec* comprimir_en_frec(int n, int* grupo){ //revisar bien cual debe ser su retorno
     int x;
    Frec* p_frec;
    p_frec = (Frec*)malloc(n*sizeof(Frec*));
    

    int* grupo2 = (int*)malloc(n*sizeof(int*));
    x = 0;
    for(int w = 0; w < n; w++){
        grupo2[w] = grupo[w];
    }
    if(n > 0){
        x++;
    }
    for(int i = 0; i < n; i++){
        int a = i + 1;
        if(grupo2[i] != 0){
            if(grupo[a] == 0){
                x++;
                grupo2[i] = 0;
            }
            for(int j = a; j < n; j++){
                if( grupo[i] != grupo2[j]){
                    x++;
                    for(int y = 0; y < n; y++){
                        if(grupo[i] == grupo2[y]){
                            grupo2[y] = 0;
                        }
                        if(grupo[j] == grupo2[y]){
                            grupo2[y] = 0;
                        }
                    }
                }      
            }          
        }
                 
    }
    free((void*)grupo2);
    
    int* numerosdiferentes = (int*)malloc(x*sizeof(int*));
    int* cantidadNumero = (int*)malloc(x*sizeof(int*));
    int* cantidadNumero2 = (int*)malloc(x*sizeof(int*));

    int* grupo3 = (int*)malloc(n*sizeof(int*));
    for(int w = 0; w < n; w++){
        grupo3[w] = grupo[w];
    }
    int s = 0;
    
    for(int i = 0; i < n; i++){
        int a = i + 1;
        if(grupo3[i] != 0){
            if(grupo[a] == 0){
                s++;
                numerosdiferentes[s];
                grupo2[i] = 0;
            }
            for(int j = a; j < n; j++){
                if( grupo[i] != grupo3[j]){
                    numerosdiferentes[s] = grupo[i];
                    s++;
                    numerosdiferentes[s] = grupo[j];
                    for(int y = 0; y < n; y++){
                        if(grupo[i] == grupo3[y]){
                            grupo2[y] = 0;
                        }
                        if(grupo[j] == grupo3[y]){
                            grupo2[y] = 0;
                        }
                    }
                }      
            }        
        }           
    }
    for(int i = 0; i < x; i++){
        int q = 0;
        for(int j = 0; j < n; j++){
            if(numerosdiferentes[i] == grupo[j]){
                q++;
            }
        }
        cantidadNumero[i] = q;
        cantidadNumero2[i] = q;
    }

    free((void*)grupo3);
    int e = 1;
    int k, v;
    k = 0;
    v = 0;


    
     for(int m = 0; m < x; m++){
        int mayor = 0;
        for(int u = 0; u < x; u++){
            if(cantidadNumero[u]>mayor){
                mayor = cantidadNumero[u];
            }
        }
        for(int o = 0; o < x; o++){ // p_frec->representaciones
            if(cantidadNumero[o] == mayor){
                for(int t = 0; t < numerosdiferentes[o]; t++){
                    k++;
                }
                // k++ por el 0
                k++;
                // k++ por la representacion
                k += e;
                cantidadNumero[o] = 0; 
            }
            for(int z = 0; z < n; z++){//frec.bits
                if(mayor == grupo[z]){
                    v += e;
                }
                if(grupo[z + 1] != 0){

                    v++;
                }
            }
            
        }
        if(cantidadNumero[m + 1] != 0){
            k++; // 0 divisor
        }
        
        e += 1;
    }
    free((void*)cantidadNumero);

    p_frec->representaciones = (char*)malloc(k*sizeof(char*));
    p_frec->bits = (char*)malloc(v*sizeof(char*));
    int b = 0;
    int d = 0;
    char r = 1;
    
    
    for(int m = 0; m < x; m++){
        int mayor;
        for(int u = 0; u < x; u++){
            if(cantidadNumero2[u]>mayor){
                mayor = cantidadNumero2[u];
            }
        }
        for(int o = 0; o < x; o++){ // p_frec->representaciones
            if(cantidadNumero2[o] == mayor){
                for(int t = 0; t < numerosdiferentes[o]; t++){
                    p_frec->representaciones[b] = 1;
                    b++;
                }
                p_frec->representaciones[b] = 0;
                b++;

                p_frec->representaciones[b] = r;
                b++;

                cantidadNumero2[o] = 0;
                
            }
            for(int z = 0; z < n; z++){//frec.bits
                if(mayor == grupo[z]){
                    p_frec->bits[d] = r;
                    d++;
                }
                if(grupo[z + 1] != 0){
                    p_frec->bits[d + 1] = 0;
                    d++;
                }
            } 
        }
        if(p_frec->representaciones[0] == 1){
            p_frec->representaciones[b] = 0;
            b++;
        }
        
        
        r += 1;
    }
    free((void*)cantidadNumero2);
    free((void*)numerosdiferentes);
    
    return p_frec;
}


int* descomprimir_en_frec(void* frec){
    Frec* frecu = (Frec*) frec;
    int largobits = sizeof(frecu->bits)/sizeof(char*);
    int largorepresentaciones = sizeof(frecu->representaciones)/sizeof(char*);
    char* descom = (char*)malloc(largoTotal);
    for(int i = 0; i < largobits; i++){
        descom[i] = frecu->bits[i];
    }
    for(int i = 0; i < largorepresentaciones; i++){
        descom[i] = frecu->representaciones[i];
    }
    return descom;

}

int  donde_esta_frec(void* frec , int e, int i){
    Frec* frecu = (Frec*) frec;
    int largobits = sizeof(frecu->bits)/sizeof(char*);
    
    int q = 0;
    int p = 0;
    
    for(int x = 0; x < largobits i, x++){
        p++;
        if(frecu->bits[x] == e){
            q++;
            if(q == i){
                return p;
            }
        }
        
    }
    return -1;

}

int  cuantos_mas_grande_frec(void* frec , int e){
    Frec* frecu = (Frec*) frec;
    int largobits = sizeof(frecu->bits)/sizeof(char*);
    int largorepresentaciones = sizeof(frecu->representaciones)/sizeof(char*);
    int x = y = 0; 
    for(int i = 0; i < largobits; i++){
        if(frecu->bits[i] != 0 ){
            x++;
        }
        else{
            if(x > e){
                y++;
                x = 0;
            }
        }
    }
    return x;

}

int  bits_frec(void* frec){
    Frec* frecu = (Frec*) frec;
    int largobits = sizeof(frecu->bits)/sizeof(char*);
    int largorepresentaciones = sizeof(frecu->representaciones)/sizeof(char*);
    int largoTotal = largobits + largorepresentaciones;
    return largoTotal;

}

void  mostrar_frec(void* frec){
    Frec* frecu = (Frec*) frec;
    int largobits = sizeof(frecu->bits)/sizeof(char*);
    int largorepresentaciones = sizeof(frecu->representaciones)/sizeof(char*);
    printf("Segun Frecuencia:");
    printf("\n");
    for(int i = 0; i < largobits; i++){
        printf(" %d",frecu->bits[i]);
    }
    printf("\n");
    for(int j = 0; j < largorepresentaciones; j ++){
        printf(" %d", frecu->representaciones[j]);
    }
    return;    
}


Sofía Parada
202004671-9

El programa tiene la funcion de decomrimir un conjunto grande de numeros de 3 diferente formas:
unario, frecuencia e incremento, que nos ayudan a determinar cual tiene menos bits para trabajar con ellos.
El archivo main.c esta conectado con los archivos Unario.c Unario.h Frec.c Frec.h Inc.c Inc.h 
que estanunidor por el makefile.

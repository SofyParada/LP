Sofía Parada
202004671-9

Para la utilización de este trabajo se necesita usar DrRacket, donde se podran ejecutar diversas 
funciones con distintos objetivos.